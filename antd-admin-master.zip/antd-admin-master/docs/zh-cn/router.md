# 路由

本项目中采用约定式路由

参考[umi 路由](https://umijs.org/zh/guide/router.html)
